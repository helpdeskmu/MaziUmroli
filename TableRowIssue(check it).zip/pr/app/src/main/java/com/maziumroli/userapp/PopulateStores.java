package com.maziumroli.userapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class PopulateStores extends Activity {


    private Context context;


    private int gridCol = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.populate_stores);
        final GridLayout gridLayout = (GridLayout)findViewById(R.id.grdShops);

        Intent intent = getIntent();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
       DocumentReference shopRef = db.document((String) intent.getStringExtra("CollectionPath"));
        final ProgressBar spinner = (ProgressBar)findViewById(R.id.progressBar1);
        spinner.setVisibility(View.VISIBLE);
        shopRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()) {
                    Map<String, Object> area  = documentSnapshot.getData();
                    for(Map.Entry<String,Object> entry : area.entrySet())
                    {
                        gridLayout.addView(AreaButtons(PopulateStores.this, (String) entry.getValue(),(String)entry.getKey()),gridCol);
                        gridCol++;
                    }
                }
                else {
                    Toast.makeText(PopulateStores.this,"इथे कोणतेही दुकान उपलब्ध नाही",Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(PopulateStores.this,"आपले इंटरनेट कनेक्शन तपासा",Toast.LENGTH_SHORT).show();
            }
        }).addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                spinner.setVisibility(View.GONE);
            }
        });

    }

    public Button AreaButtons(final Context context, String text, final String storeId)
    {
        final ConstraintLayout.LayoutParams lparam = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT);
        lparam.topMargin = 30;
        lparam.rightMargin=30;
        lparam.leftMargin=30;
        lparam.bottomMargin=10;
        final Button button = new Button(context);
        button.setText(text);
        button.setContentDescription(storeId);
        button.setLayoutParams(lparam);
        button.setBackground(ContextCompat.getDrawable(context, R.drawable.roundcorners) );
        button.setTextColor(Color.WHITE);
        button.setTextSize(24);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PopulateStores.this,ProductList.class);
                i.putExtra("StoreId",storeId);
                startActivity(i);
            }
        });
        return button;
    }

}
