package com.maziumroli.userapp;

import androidx.annotation.RequiresApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductList extends Activity {
    private Context context;
    GridLayout gridLayout;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private int gridCol = 0;
    private final int TIME_PICKER_INTERVAL=15;
    private boolean mIgnoreEvent=false;
    final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    Map<String,Map<String,List<Products>>> products=new HashMap<String,Map<String,List<Products>>>();
    TableLayout tableLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_list);
        gridLayout = (GridLayout) findViewById(R.id.lstButtons);
        tableLayout = (TableLayout) findViewById(R.id.tblLayout);
        final TextView totalItems = (TextView)findViewById(R.id.txtTotal);
        Button addbutton = (Button)findViewById(R.id.btnAdd);
        final EditText prodName = (EditText)findViewById(R.id.txtProdName);
        final EditText qty = (EditText)findViewById(R.id.txtQty);
        final Spinner type = (Spinner)findViewById(R.id.ddltype);
        final Button btnSend = (Button) findViewById(R.id.btnSend);
        totalItems.setText("एकूण: " + gridCol);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowTimerPickerAlert(tableLayout);
            }

        });

        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(prodName.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(),"सामानाचे नाव लिहा",Toast.LENGTH_LONG).show();;
                        return;
                    }
                    if(qty.getText().toString().equals(""))
                    {
                        Toast.makeText(getApplicationContext(),"संख्या लिहा",Toast.LENGTH_LONG).show();;
                        return;
                    }


                    final TableLayout tblList = findViewById(R.id.tblLayoutList);
                    final TableRow row = new TableRow(ProductList.this);
                    TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,TableRow.LayoutParams.WRAP_CONTENT);
                    row.setGravity(Gravity.CENTER);
                    lp.setMargins(2, 2, 2, 2);

                    TableRow.LayoutParams textViewparam = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
                    textViewparam.setMargins(2,3,49,3);
                    row.setLayoutParams(lp);
                    TextView txtProdName = new TextView(ProductList.this);
                    txtProdName.setWidth(540);                                          // ########################### removed width attribute
                    txtProdName.setTextSize(20);
//                    txtProdName.setPadding(100,10,100,10);             // ########################### give a padding
//                    txtProdName.setMaxWidth(350);                                       // ########################### MAX WIDTH set babe
                    txtProdName.setLayoutParams(textViewparam);
                    txtProdName.setText(prodName.getText());
                    TextView txtQty = new TextView(ProductList.this);
                    txtQty.setTextSize(20);
                    txtQty.setText(qty.getText());
                    txtQty.setLayoutParams(textViewparam);
                    txtQty.setTextColor(Color.parseColor("#00FF00"));
                    TextView typeQty = new TextView(ProductList.this);
                    typeQty.setTextSize(20);
                    typeQty.setTextColor(Color.parseColor("#2196F3"));
                    typeQty.setLayoutParams(textViewparam);
                    typeQty.setText(type.getSelectedItem().toString());
                    TableRow.LayoutParams btnParam = new TableRow.LayoutParams(
                            TableRow.LayoutParams.WRAP_CONTENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    btnParam.setMargins(25,13,25,13);
                    Button btnRemove = new Button(ProductList.this);
                    btnRemove.setLayoutParams(btnParam);
                    btnRemove.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            tblList.removeView(row);
                            gridCol--;
                            totalItems.setText("एकूण: " + gridCol);
                            ShowHideSendButton(gridCol,btnSend);
                        }
                    });
                    //btnRemove.setTextColor(Color.WHITE);
                    btnRemove.setText("X");
                    btnRemove.setTextSize(10);
                    row.addView(txtProdName);
                    row.addView(txtQty);
                    row.addView(typeQty);
                    row.addView(btnRemove);
                    tblList.addView(row, gridCol);
                    gridCol++;
                    totalItems.setText("एकूण: " + gridCol);
                    prodName.setText("");
                    qty.setText("");
                    ShowHideSendButton(gridCol,btnSend);
                }
                catch(Exception e)
                {
                    throw e;
                }
            }
        });
    }

    void ShowTimerPickerAlert(final TableLayout tableLayout)
    {
        final AlertDialog.Builder alert = new AlertDialog.Builder(ProductList.this);
        View mView = getLayoutInflater().inflate(R.layout.custom_timepicker,null);
        Button btn_okay = (Button)mView.findViewById(R.id.btn_okay);
        final TimePicker timePicker = (TimePicker) mView.findViewById(R.id.timePicker);
        Calendar c = Calendar.getInstance();
        timePicker.setCurrentHour(new Integer(12));
        timePicker.setCurrentMinute(new Integer(00));

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if (mIgnoreEvent)
                    return;
                if (minute % TIME_PICKER_INTERVAL != 0) {
                    int minuteFloor = minute - (minute % TIME_PICKER_INTERVAL);
                    minute = minuteFloor + (minute == minuteFloor + 1 ? TIME_PICKER_INTERVAL : 0);
                    if (minute == 60)
                        minute = 0;
                    mIgnoreEvent = true;
                    view.setCurrentMinute(minute);
                    mIgnoreEvent = false;
                }
            }
        });

        alert.setView(mView);
        final Intent i = getIntent();
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_okay.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Map<String,Products> lstProducts= new HashMap<String,Products>();
                List<Products> lstItems = new ArrayList<Products>();
                for(int i=0; i < tableLayout.getChildCount();i++)
                {
                    TableRow mRow = (TableRow) tableLayout.getChildAt(i);
                    TableRow.LayoutParams rlp = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    mRow.setLayoutParams(rlp);
                    TextView pName = (TextView) mRow.getChildAt(0);
                    TextView qty = (TextView) mRow.getChildAt(1);
                    TextView type = (TextView) mRow.getChildAt(2);
                    Products p= new Products(pName.getText().toString(),qty.getText().toString(),type.getText().toString());
                    lstProducts.put(pName.getText().toString(), p);
                }
                //save values in database
                db.collection((String)i.getStringExtra("StoreId")).document(user.getUid()).set(lstProducts);
                //end
                timePicker.setIs24HourView(false);

                String timeInhr="";
                final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
                String time = String.valueOf(timePicker.getHour()) + ":" +  String.valueOf(timePicker.getMinute());
                try {
                    final Date dateObj = sdf.parse(time);
                    timeInhr = new SimpleDateFormat("k:mm").format(dateObj) + (timePicker.getHour() < 12 ? " AM" : " PM");
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Intent intent = new Intent(ProductList.this,submit_info.class);
                intent.putExtra("AppointmentTime",timeInhr);
                startActivity(intent);
            }
        });
        alertDialog.show();
    }
    void ShowHideSendButton(int count,Button btn)
    {
        if (count > 0) {
            btn.setVisibility(View.VISIBLE);
        } else {
            btn.setVisibility(View.GONE);
        }
    }
}

class Products
{
    String productName;
    String qty;
    String  type;
    public Products(String productName, String qty, String type) {
        this.productName = productName;
        this.qty = qty;
        this.type = type;
    }

    public String getProductName()
    {
    return this.productName;
    }
    public String getQty()
    {
    return this.qty;
    }
    public String getType()
    {
    return this.type;
    }
}

