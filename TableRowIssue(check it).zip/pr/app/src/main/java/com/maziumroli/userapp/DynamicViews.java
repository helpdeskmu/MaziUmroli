package com.maziumroli.userapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import org.w3c.dom.Text;

public class DynamicViews extends Activity {
   Context _context;
MainActivity main = new MainActivity();
    public DynamicViews(Context context) {
        this._context = context;
    }

    public Button AreaButtons(final Context context, String text, final String btnId)
    {
        final FrameLayout.LayoutParams lparam = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        lparam.topMargin = 62;
        lparam.bottomMargin = 10;
        final Button button = new Button(context);
        button.setText(text);
        button.setContentDescription(btnId);
        button.setLayoutParams(lparam);
        button.setBackground(ContextCompat.getDrawable(context, R.drawable.roundcorners) );
        button.setTextColor(Color.WHITE);
        button.setTextSize(24);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        return button;
    }

}
