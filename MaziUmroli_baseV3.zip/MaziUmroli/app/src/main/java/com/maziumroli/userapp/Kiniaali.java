package com.maziumroli.userapp;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class Kiniaali extends AppCompatActivity {
    ListView lv;
    String[]kiniaalishops = {"store1","store2","store3","store4","store5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kiniaali);

        ArrayAdapter ad = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,kiniaalishops);
        lv = (ListView) findViewById(R.id.chaukipadalist);
        lv.setAdapter(ad);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                switch (selectedItem){
                    case "store1":

                        break;
                }
            }
        });
    }
}
