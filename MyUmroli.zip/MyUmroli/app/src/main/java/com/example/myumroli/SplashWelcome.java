package com.example.myumroli;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashWelcome extends AppCompatActivity {

    private static int SPLASH_SCREEN = 4000;

        Animation topanim, bottomanim;
        ImageView welcomelogo;
        TextView welcomeappname;
        ProgressBar welcomeprogress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_welcome);


        topanim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);

        welcomelogo = (ImageView) findViewById(R.id.welcomelogo1);
        welcomeappname = (TextView) findViewById(R.id.welcomeappname);
        welcomeprogress = (ProgressBar) findViewById(R.id.welcomeprogress);

        welcomelogo.setAnimation(topanim);
        welcomeappname.setAnimation(bottomanim);
        welcomeprogress.setAnimation(bottomanim);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashWelcome.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, SPLASH_SCREEN);
    }
}
