package com.example.myumroli;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NakaAaliStore1 extends AppCompatActivity {

    Button send;
    EditText text1;

    FirebaseDatabase database;
    DatabaseReference myref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naka_aali_store1);

        send = (Button) findViewById(R.id.sendbutton);
        text1 = (EditText) findViewById(R.id.text1);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = text1.getText().toString();

                database = FirebaseDatabase.getInstance();
                myref = database.getReference("messages").child("customer");
                myref.setValue(data);
            }
        });
    }
}
