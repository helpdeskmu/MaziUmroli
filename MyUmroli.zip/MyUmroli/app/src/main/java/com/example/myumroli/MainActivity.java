package com.example.myumroli;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button nakaaali,kiniaali,gharataali,patilaali,aadarshnagar,chaukipada,sainagar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nakaaali = (Button) findViewById(R.id.nakaaali);
        kiniaali = (Button) findViewById(R.id.kiniaali);
        gharataali = (Button) findViewById(R.id.gharataali);
        patilaali = (Button) findViewById(R.id.patilaali);
        aadarshnagar = (Button) findViewById(R.id.aadarshnagar);
        chaukipada = (Button) findViewById(R.id.chaukipada);
        sainagar = (Button) findViewById(R.id.sainagar);

        nakaaali.setOnClickListener(this);
        kiniaali.setOnClickListener(this);
        gharataali.setOnClickListener(this);
        patilaali.setOnClickListener(this);
        aadarshnagar .setOnClickListener(this);
        chaukipada.setOnClickListener(this);
        sainagar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int getter = v.getId();
        Intent i;

        switch (getter){
            case R.id.nakaaali:
                i = new Intent(MainActivity.this,Nakaaali.class);
                startActivity(i);
                break;
            case R.id.kiniaali:
                i = new Intent(MainActivity.this,Kiniaali.class);
                startActivity(i);
                break;
            case R.id.gharataali:
                i = new Intent(MainActivity.this,Gharataali.class);
                startActivity(i);
                break;
            case R.id.patilaali:
                i = new Intent(MainActivity.this,Patilaali.class);
                startActivity(i);
                break;
            case R.id.aadarshnagar:
                i = new Intent(MainActivity.this,Aadarshnagar.class);
                startActivity(i);
                break;
            case R.id.chaukipada:
                i = new Intent(MainActivity.this,Chaukipada.class);
                startActivity(i);
                break;
            case R.id.sainagar:
                i = new Intent(MainActivity.this,Sainagar.class);
                startActivity(i);
                break;
        }

    }
}
