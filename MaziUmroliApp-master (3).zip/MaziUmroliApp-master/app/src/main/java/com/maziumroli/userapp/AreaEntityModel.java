package com.maziumroli.userapp;

import java.util.Dictionary;

public class AreaEntityModel {
    public final Dictionary<String,String> AreaName;

    public AreaEntityModel(Dictionary<String,String> areaName) {
        AreaName = areaName;
    }
}

class Area
{

    public final String AreaName;

    public Area(String areaName) {
        AreaName = areaName;
    }
    public String getAreaName()
    {
        return this.AreaName;
    }
}

