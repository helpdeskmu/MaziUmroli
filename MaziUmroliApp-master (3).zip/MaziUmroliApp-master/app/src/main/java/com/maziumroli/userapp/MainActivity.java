package com.maziumroli.userapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class MainActivity extends Activity implements View.OnClickListener {
    DynamicViews dynamicView;
    private GridLayout gridLayout;
    private Context context;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DocumentReference areaRef = db.document("Area/Umroli");
    private int gridCol = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            gridLayout = (GridLayout) findViewById(R.id.lstButtons);

            final ProgressBar spinner = (ProgressBar) findViewById(R.id.progressBar1);
            spinner.setVisibility(View.VISIBLE);
            areaRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    if (documentSnapshot.exists()) {
                        Map<String, Object> area = documentSnapshot.getData();
                        for (Map.Entry<String, Object> entry : area.entrySet()) {
                            dynamicView = new DynamicViews(context);
                            gridLayout.addView(AreaButtons(MainActivity.this, (String) entry.getValue(), (String) entry.getKey()), gridCol);
                            gridCol++;
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Document Not Exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MainActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                }
            }).addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    spinner.setVisibility(View.GONE);
                }
            });
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    @Override
    public void onClick(View v) {

    }

    public Button AreaButtons(final Context context, String text, final String subAreaId)
    {
        final ConstraintLayout.LayoutParams lparam = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT);
        lparam.topMargin = 30;
        lparam.rightMargin=30;
        lparam.leftMargin=30;
        lparam.bottomMargin=10;
        final Button button = new Button(context);
        button.setText(text);
        button.setContentDescription(subAreaId);
        button.setLayoutParams(lparam);
        button.setBackground(ContextCompat.getDrawable(context, R.drawable.roundcorners) );
        button.setTextColor(Color.WHITE);
        button.setTextSize(24);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,Shops.class);
                intent.putExtra("SubAreaId",subAreaId);
                startActivity(intent);
            }
        });
        return button;
    }

}
