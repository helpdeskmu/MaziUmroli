package com.maziumroli.userapp.phoneauthentication;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.maziumroli.userapp.R;


public class enterName extends AppCompatActivity {


    private EditText editTextName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entername);

        editTextName = findViewById(R.id.editTextName);

        findViewById(R.id.buttonContinue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userName = editTextName.getText().toString().trim();

                if (userName.isEmpty()) {
                    editTextName.setError("Enter your name");
                    editTextName.requestFocus();
                    return;
                }

                Intent intent = new Intent(enterName.this, MainEnterPhoneNo.class);
                intent.putExtra("userName", userName);
                startActivity(intent);
            }
        });
    }
}