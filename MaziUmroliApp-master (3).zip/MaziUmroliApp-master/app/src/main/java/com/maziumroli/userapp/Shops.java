package com.maziumroli.userapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.w3c.dom.Text;

import java.util.Map;

public class Shops extends Activity implements View.OnClickListener {
    FirebaseFirestore db = com.google.firebase.firestore.FirebaseFirestore.getInstance();
    DocumentReference areaRef = db.document("Area/Umroli");
    static int gridCol = 2;
    private Context context;
    DynamicViews dynamicView;
    static String collectionPath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.area_shops);
        ImageButton groceryShop = (ImageButton) findViewById(R.id.GroceryShop);
        ImageButton milkDairy = (ImageButton) findViewById(R.id.milkDairy);
        ImageButton vegetableShop = (ImageButton) findViewById(R.id.vegetableShop);
        ImageButton hotel = (ImageButton) findViewById(R.id.hotel);
        ImageButton medicalShop = (ImageButton) findViewById(R.id.medicalShop);
        ImageButton chickenShop = (ImageButton) findViewById(R.id.chickenShop);
        groceryShop.setOnClickListener(this);
        milkDairy.setOnClickListener(this);
        vegetableShop.setOnClickListener(this);
        hotel.setOnClickListener(this);
        medicalShop.setOnClickListener(this);
        chickenShop.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        try {
            Intent intent = getIntent();
            int id = v.getId();
            switch (id) {
                case R.id.GroceryShop:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/GroceryShop";
                    break;
                case R.id.medicalShop:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/MedicalShop";
                    break;
                case R.id.milkDairy:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/MilkDairy";
                    break;
                case R.id.hotel:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/Hotel";
                    break;
                case R.id.vegetableShop:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/VegetableShop";
                    break;
                case R.id.chickenShop:
                    collectionPath = (String) intent.getStringExtra("SubAreaId") + "/ChickenShop";
                    break;

            }
            Intent intent1 = new Intent(Shops.this, PopulateStores.class);
            intent1.putExtra("CollectionPath", collectionPath);
            startActivity(intent1);
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}
